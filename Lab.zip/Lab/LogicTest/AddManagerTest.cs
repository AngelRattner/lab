﻿using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;
using DAL.Context;
using Logic;
using Logic.Managers;
using Entity;

namespace LogicTest
{
    [TestClass]
    class AddManagerTest
    {
        private DbContextOptions<WritesContext> _options;

        [TestInitialize]
        public void Init()
        {
            _options = new DbContextOptionsBuilder<WritesContext>().UseInMemoryDatabase(databaseName: "DbContextDatabase").Options;
        }
        public void CleanUp()
        {
            using var dbContext = new WritesContext(_options);
            dbContext.Writes.RemoveRange(dbContext.Writes);
            dbContext.SaveChanges();
        }


        [TestMethod]
        public void TestAdd()
        {
            //Arrange
            using var dbContext = new WritesContext(_options);
            AddManager logic = new AddManager();
            Book book = new Book("TestName", "TestAuthor", "TestPublisher", DateTime.Now, 20, "TestGenres");
            //Act
            logic.Add(book,);
        }
    }
}
