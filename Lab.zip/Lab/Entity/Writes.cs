﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entity
{
    public class Writes
    {
        public float discount { get; set; }
        public string _rentBy { get; set; }
        public DateTime rent_date { get; set; }
        const int _sizeOfbyte = 8; //to make a random guid

        Random rand = new Random();

        public bool isrented { get; set; }
        public Guid ID { get; set; } //id for book
        public string _name { get; set; }
        public string _publisher { get; set; }
        public float _price { get; set; }
        public string _geners { get; set; }
        public DateTimeOffset _publish_date { get; set; }
        public Writes(string name, string publisher, DateTimeOffset publish_date, float price, string geners)
        {
            rand = new Random();
            _name = name;
            _publisher = publisher;
            _publish_date = publish_date;
            _price = price;
            _geners = geners;
            ID = crateGuid();
            isrented = false;
            discount = 0;
        }

        public override string ToString()
        {
            if (isrented) return $"ID: {ID}, {_name} publisher: {_publisher}, publish: {_publish_date } \n geners:{_geners} , price: {_price}, discount {discount} %, ranted: {isrented} by:{_rentBy}, {rent_date}";
            else return $"ID:{ID}, {_name} publisher: {_publisher}, publish: {_publish_date } \n geners: {_geners} , price: {_price} , discount {discount} %, ranted {isrented}";
        }

        //put in another class?
        public Guid crateGuid()
        {
            byte[] arrbyte = new byte[_sizeOfbyte];
            for (int i = 0; i < _sizeOfbyte; i++)
            {
                arrbyte[i] = (byte)rand.Next((int)(byte.MaxValue + 1));
            }
            return new Guid(rand.Next(), (short)rand.Next((int)short.MinValue, (int)short.MaxValue + 1), (short)rand.Next((int)short.MinValue, (int)short.MaxValue + 1), arrbyte);
        }

    }
}
