﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entity
{
    public class User
    {
        public string Name { get; set; }
        public string Password { get; set; }
        public bool IsRentingNow { get; set; }
    }
}
