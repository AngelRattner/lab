﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entity
{
    public class Book : Writes
    {
        public string _author { get; set; }

        public Book(string name, string author, string publisher, DateTimeOffset publish_date, float price, string geners) : base(name, publisher, publish_date, price, geners)
        {
            _author = author;
        }
        public override string ToString()
        {
            return $"by {_author} " + base.ToString();
        }
    }
}
