﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entity
{
    public class Magazine : Writes
    {
        public Magazine(string name, string publisher, DateTimeOffset publish_date, float price, string geners) : base(name, publisher, publish_date, price, geners)
        { }

    }
}
