﻿using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL.Context;
using DAL.Repository
using Microsoft.EntityFrameworkCore;

namespace Lib.Service
{
  public static class DataService
    {
        public static ServiceProvider serviceProvider = new ServiceCollection()
            .AddDbContext<WritesContext>(options =>
            {
                options.UseSqlite($@"Data Source = {App.DB}");
            })
            .AddScoped<IRepository>(provider => new Repository(provider.GetService<WritesContext>()))
            .BuildServiceProvider();
        public static IRepository ItemStore = serviceProvider.GetService<IRepository>();
    }
}
