﻿using Entity;
using Logic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lib.Service
{
    class WritesCollectionService
    {
        List<Writes> itemCollection;
        private I_ItemCollection ItemCollection;
        private static WritesCollectionService instance;
        private WritesCollectionService(I_ItemCollection ItemCollection)
        {
            this.ItemCollection = ItemCollection;
            itemCollection = ItemCollection.getItemsList();
        }
        public static WritesCollectionService Istance { get { return instance; } }
        public List<Writes> GetWrits() { return itemCollection; }
    } 
}

