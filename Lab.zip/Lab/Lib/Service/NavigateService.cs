﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Entity;
using System.Windows.Controls;
using System.Windows;
using Lib.ViewModel;
using Lib.Storge;

namespace Lib.Service
{
    public class NavigationService<TViewModel>
          where TViewModel : ViewModelBase
    {
        private readonly NavigateStoreg _navigationStorage;
        private readonly Func<TViewModel> _createViewModel;

        public NavigationService(NavigateStoreg navigationStorage, Func<TViewModel> createViewModel)
        {
            _navigationStorage = navigationStorage;
            _createViewModel = createViewModel;
        }

        public void Navigate()
        {
            _navigationStorage.CurrentViewModel = _createViewModel();
        }
    }
}
