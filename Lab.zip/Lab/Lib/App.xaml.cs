﻿using DAL.Context;
using Entity;
using Lib.Storge;
using Lib.ViewModel;
using Lib.ViewModels.Pages;
using Lib.Views;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;
using static Lib.Service.DataService;

namespace Lib
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static string appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
        public static string path = $@"{appData}\EFSample";
        public static string DB = $@"{path}\EFSample.db";
        // public static IEnumerable<Book> Books;
        public static IEnumerable<Writes> Writes;


        protected override void OnStartup(StartupEventArgs e)
        {
            DispatcherTimer dispatcher = new DispatcherTimer();
            dispatcher.Interval = TimeSpan.FromMilliseconds(10);
            dispatcher.Tick += Dispatcher_Tick;
            dispatcher.Start();

            if (!Directory.Exists(path)) Directory.CreateDirectory(path);
            //InitializeData();

            NavigateStoreg navigationStorage = new NavigateStoreg();

            navigationStorage.CurrentViewModel = new LoginViewModel(navigationStorage);

            MainWindow = new MainWindow()
            {
                DataContext = new MainViewModel(navigationStorage)
            };
            MainWindow.Show();

            base.OnStartup(e);
        }

        private void Dispatcher_Tick(object sender, EventArgs e)
        {
            try
            {
                ItemStore.EnsureDataBase();
                Writes = ItemStore.GetWrites();
            }
            catch (Exception ex)
            {
                File.Delete(DB);
            }
        }
    }
}
