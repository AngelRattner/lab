﻿using DAL.Repository;
using Entity;
using Lib.ViewModels.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Lib.Service.DataService;
namespace Lib.Commands
{
    public class AddBookCommand : CommandBase
    {
        AddBookViewModel addBookViewModel;
        public AddBookCommand(AddBookViewModel addBookViewModel)
        {
            this.addBookViewModel = addBookViewModel;
        }
        public override void Execute(object parameter)
        {
            if (addBookViewModel.isbook)
            {
                Book book = new Book(addBookViewModel.name, addBookViewModel.author, addBookViewModel.pub, addBookViewModel.DateTime, addBookViewModel.price, addBookViewModel.gen);
                ItemStore.AddWrites(book);
                App.Writes.ToList().Add(book);
            }
            else
            {
                Magazine magazine = new Magazine(addBookViewModel.name, addBookViewModel.pub, addBookViewModel.DateTime, addBookViewModel.price, addBookViewModel.gen);
                ItemStore.AddWrites(magazine);
                App.Writes.ToList().Add(magazine);
            }
        }
    }
}
