﻿using Entity;
using Lib.Service;
using Lib.Views;
using Logic;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lib.ViewModels.Pages
{
    public class BookCollectionViewModel 
    {
    

        public List<Writes> Items = new List<Writes>();
        private I_ItemCollection i_ItemCollection;
        public bool NotFond;
        public bool NotYourBook;
        public bool ReturnFirst;
        public string FindbyCategory;
        public string Search;
        
        public Writes SelctedWrite { get; set; }
        
        public BookCollectionViewModel(I_ItemCollection i_ItemCollection)
        {
            this.i_ItemCollection = i_ItemCollection;
            Items = i_ItemCollection.getItemsList();
        }
        

        #region select item from combobox
        ObservableCollection<OptionModel> option = new ObservableCollection<OptionModel>()
        {
              new OptionModel{Id=1, Option="name" },
              new OptionModel{Id=2, Option="publisher" },
              new OptionModel{Id=3, Option="geners" },
              new OptionModel{Id=4, Option="author" }
        };
        public ObservableCollection<OptionModel> Option { get => option; set => option = value; }
        public OptionModel SelctedOption { get; set; }
        #endregion


      
                //if (MainPage.librarian == true)
                //{
                //    isedit.IsEnabled = true;
                //    isremove.IsEnabled = true;
                //}
                //else
                //{
                //    isedit.IsEnabled = false;
                //    isremove.IsEnabled = false;
                //}
         


        public void back_Click()//go back
        {
            NavigateService.RootFrame.Navigate(typeof(LibraryView));
        }
        public void search()//search a book/mag
        {
            List<Writes> tmp = new List<Writes>(); 
            if (SelctedOption.Option == "name") tmp = i_ItemCollection.FindbyName(Search);
            else if (SelctedOption.Option=="publisher") tmp = i_ItemCollection.FindbyPublisher(Search);
            else if (SelctedOption.Option=="geners") tmp = i_ItemCollection.FindbyGeners(Search);
            else if (SelctedOption.Option=="author") tmp = i_ItemCollection.FindBYAuther(Search);

            if (tmp.Count == 0)
            {
                NotFond = true;
                return;
            }
            else Items = tmp;
        }
        public void Rent()
        {
            if (!LogedUser._LogedUser.IsRentingNow && !SelctedWrite.isrented)
            {
                i_ItemCollection.RentItem(SelctedWrite, LogedUser._LogedUser.Name);
                LogedUser._LogedUser.IsRentingNow = true;
            }
            else ReturnFirst = true; //user must return book before renting another one anf book ist rented
        }
        public void Remove() { i_ItemCollection.RemoveItem(SelctedWrite); }
        public void Edit() { NavigateService.RootFrame.Navigate(typeof(EditView),SelctedWrite); }
        public void Return()
        {
            if (LogedUser._LogedUser.Name == SelctedWrite._rentBy)
            {
                LogedUser._LogedUser.IsRentingNow = false;
                i_ItemCollection.ReturnItem(SelctedWrite);
            }
            else NotYourBook = true; //display msg saying u cant return a book that u didnt took...

        }
    }
}
