﻿using Lib.Commands;
using Lib.Service;
using Lib.Storge;
using Lib.Views;
using Logic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Lib.ViewModels.Pages
{
    public class AddBookViewModel
    {
        public ICommand Back { get; set; }
        public ICommand Add { get; set; }
        public AddBookViewModel(NavigateStoreg navigateStoreg)
        {
            Add = new AddBookCommand(this);
            Back = new NavigateCommand<LibraryViewModel>(new NavigationService<LibraryViewModel>(navigateStoreg,()=> new LibraryViewModel(navigateStoreg)));
        }
        public int pricetxt;
        public string name;
        public string author;
        public string pub;
        public DateTimeOffset DateTime;
        public string gen;
        public int price =0;
        public bool err = false;
        public bool isbook;

    }
}
