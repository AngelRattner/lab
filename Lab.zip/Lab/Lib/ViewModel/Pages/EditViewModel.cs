﻿using Entity;
using Lib.Service;
using Lib.Views;
using Logic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lib.ViewModel.Pages
{
    public class EditViewModel
    {
        I_ItemCollection I_ItemCollection;
        public EditViewModel(I_ItemCollection i_ItemColletion)
        {
            this.I_ItemCollection = i_ItemColletion;
        }
        public int pricetxt;
        public string name;
        public string author;
        public string pub;
        public DateTimeOffset DateTime;
        public string gen;
        public int price = 0;

        public bool err = false;
        Writes writes;//= to the selected item from BookCollection page

        public void Add()
        {
            if (writes is Entity.Book)
            {
                if (name != "" && author != "" && pub != "" && DateTime != null && gen != "" && price != 0)
                {

                    I_ItemCollection.EditItem(writes,name, author, pub, DateTime, price, gen);//chang func to create book
                    NavigateService.RootFrame.Navigate(typeof(LibraryView));
                }
                else err = true;
            }
            else
            {
                if (name != "" && pub != "" && DateTime != null && gen != "" && price != 0)
                {
                    I_ItemCollection.EditItem(writes,name, pub, DateTime, price, gen);
                    NavigateService.RootFrame.Navigate(typeof(LibraryView));
                }
                else err = true;
            }
        }

        public void Back()
        {
            NavigateService.RootFrame.Navigate(typeof(LibraryView));
        }
    }
}
