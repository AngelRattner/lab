﻿using Entity;
using Lib.Service;
using Lib.Views;
using Logic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lib.ViewModels.Pages
{
    public class DiscountViewModel
    {
        List<Writes> Items;
        I_ItemCollection i_ItemCollection;
        List<Writes> tmp;

        public string name;

        public bool publisher;
        public bool Date;
        public bool author;
        public bool geners;

        public int discount;
        int year;

        public void pub() { publisher = !publisher; }
        public void date() { Date = !Date; }
        public void auth() { author = !author; }
        public void gen() { geners = !geners; }

        public DiscountViewModel(I_ItemCollection i_ItemCollection)
        {
            this.i_ItemCollection = i_ItemCollection;
            Items = i_ItemCollection.getItemsList();
        }
        public void SetDiscount()//ADD DISCOUNT
        {
            if (publisher is true)//publisher
            {
                tmp = i_ItemCollection.FindbyPublisher(name);
            }

            else if (Date is true)//publish date
            {
              if(int.TryParse(name, out year))tmp = i_ItemCollection.FindBYDate(year);
            }
            else if (author is true)//author
            {
                tmp = i_ItemCollection.FindBYAuther(name);
            }
            else if (geners is true)//geners
            {
                tmp = i_ItemCollection.FindbyGeners(name);
            }
            if (tmp.Count != 0)
            {
                foreach (var item in tmp)
                {
                    i_ItemCollection.SetDiscount(item,discount);
                }
            }
            NavigateService.RootFrame.Navigate(typeof(LibraryView));
        }//set discount

        public void Back()//exit
        {
            NavigateService.RootFrame.Navigate(typeof(LibraryView));
        }

        public void RemoveDiscount()//REMOVE DISCOUNT
        {
           if (publisher is true)//publisher
            {
                tmp = i_ItemCollection.FindbyPublisher(name);
            }

            else if (Date is true)//publish date
            {
              if(int.TryParse(name, out year))tmp = i_ItemCollection.FindBYDate(year);
            }
            else if (author is true)//author
            {
                tmp = i_ItemCollection.FindBYAuther(name);
            }
            else if (geners is true)//geners
            {
                tmp = i_ItemCollection.FindbyGeners(name);
            }
            if (tmp.Count != 0)
            {
                foreach (var item in tmp)
                {
                    i_ItemCollection.RemoveDiscount(item);
                }
            }
            NavigateService.RootFrame.Navigate(typeof(LibraryView));
        }//end sicount
    }
}
