﻿using Entity;
using Lib.Service;
using Lib.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lib.ViewModels.Pages
{
    public class LoginViewModel
    {
        public User user { get; set; }
        public bool err = false;
        public void Login()
        {
            if (user.Name == "Angel" && user.Password == "123")
            {
                LogedUser.IsLibrarian = true; //ck if its labr
                LogedUser._LogedUser = user;
                NavigateService.RootFrame.Navigate(typeof(LibraryView));
                return;
            }
            else if (user.Name == "" || user.Password == "")
            {
                err = true; //ck that u put something
                return;
            }
            LogedUser.IsLibrarian = false;
            LogedUser._LogedUser = user;
            NavigateService.RootFrame.Navigate(typeof(LibraryView));
        }
    }
}
