﻿using Entity;
using Lib.Service;
using Lib.Views;
using Logic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lib.ViewModels.Pages
{
    public class LibraryViewModel
    {

        public bool _Add = false;
        public bool _Discount = false;

        List<Writes> Items;

        public string ReportText = "";
        int cont = 0;
        int book = 0;
        int late = 0;
        int mag = 0;

        public LibraryViewModel()
        {

            Items = itemCollection.getItemsList();

            if (LogedUser.IsLibrarian == true)
            {
                _Add = true;
                _Discount = true;
            }
        }

        public void add_Click()//add book/mag
        {
            //NavigateService.RootFrame.Navigate(typeof(AddBookView));
        }

        public void show_Click()//show all the books and able to rent one
        {
            //NavigateService.RootFrame.Navigate(typeof(BookCollectionView));
        }

        public void _out_Click() //log out
        {
            NavigateService.RootFrame.Navigate(typeof(LoginView));
        }

        public void DailyReport()
        {
            for (int i = 0; i < Items.Count; i++)
            {
                if (Items[i] is Entity.Book) book++;
                else mag++;
                if (Items[i].isrented) cont++;
                if ((Items[i].rent_date - DateTime.Now).TotalDays > 14) late++;
            }
            ReportText = $"we have {book} books \n we have {mag} magazine \n {cont} is rented out of {Items.Count} items \n{late} customer are late to return there books/magazins";
        }

        public void Discount()
        {
           // NavigateService.RootFrame.Navigate(typeof(DiscountView)); ;
        }
    }
}
