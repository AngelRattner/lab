using GalaSoft.MvvmLight;
using Lib.Storge;

namespace Lib.ViewModel
{
    /// <summary>
    /// This class contains properties that the main View can data bind to.
    /// <para>
    /// Use the <strong>mvvminpc</strong> snippet to add bindable properties to this ViewModel.
    /// </para>
    /// <para>
    /// You can also use Blend to data bind with the tool's support.
    /// </para>
    /// <para>
    /// See http://www.galasoft.ch/mvvm
    /// </para>
    /// </summary>
    public class MainViewModel : ViewModelBase
    {
        private readonly NavigateStoreg _navigationStorage;

        public ViewModelBase CurrentViewModel => _navigationStorage.CurrentViewModel;
        public MainViewModel(NavigateStoreg navigationStorage)
        {
            _navigationStorage = navigationStorage;

            _navigationStorage.CurrentViewModelChanged += OnCurrentViewModelChanged;
        }

        private void OnCurrentViewModelChanged()
        {
            OnPropertyChanged(nameof(CurrentViewModel));
        }
    }
}