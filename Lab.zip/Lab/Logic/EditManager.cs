﻿using DAL.Repository;
using Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace Logic
{
    class EditManager
    {
        private IRepository repository;
        public EditManager(IRepository repository)
        {
            this.repository = repository;
        }

        public void Edit(Writes writes)
        {
            repository.EditWrite(writes);
        }
    }
}
