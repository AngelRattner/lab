﻿using System;
using System.Collections.Generic;
using System.Text;
using DAL.Repository;
using Entity;

namespace Logic.Managers
{
    public class AddManager
    {
        private IRepository repository;
        public AddManager(IRepository repository)
        {
            this.repository = repository;
        }

        public List<Writes> Add(Writes a, List<Writes> Items)
        {
            if (Items.Contains(a)) throw new Exception("this Writes already in the item collection");
            repository.AddWrites(a);
            Items.Add(a);
            return Items;
        }
    }
}
