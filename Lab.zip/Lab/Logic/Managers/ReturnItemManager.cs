﻿using DAL.Repository;
using Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace Logic.Managers
{
    class ReturnItemManager
    {
        private IRepository repository;
        public ReturnItemManager(IRepository repository)
        {
            this.repository = repository;
        }
        public void Return(Writes writes)
        {
            writes.isrented = false;
            repository.EditWrite(writes);
        }
    }
}
