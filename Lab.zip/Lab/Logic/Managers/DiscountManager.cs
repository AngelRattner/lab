﻿using DAL.Repository;
using Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace Logic.Managers
{
    class DiscountManager
    {
        private IRepository repository;
        public DiscountManager(IRepository repository)
        {
            this.repository = repository;
        }

        public void SetDiscount(Writes writes, int discount)
        {
            writes.discount = discount;
            repository.SetDiscount(writes);
        }

        public void RemoveDiscount(Writes writes)
        {
            writes.discount = 0;
            repository.SetDiscount(writes);
        }

    }
}
