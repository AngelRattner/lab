﻿using DAL.Repository;
using Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace Logic.Managers
{
    class RentItemManager
    {
        private IRepository repository;
        public RentItemManager(IRepository repository)
        {
            this.repository = repository;
        }

        public void Rent(Writes a,string name)
        {
            a.isrented = true;
            a._rentBy = name;
            repository.EditWrite(a);
        }
    }
}
