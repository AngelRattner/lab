﻿using Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace Logic.Managers
{
    class FindWriteManager
    {
        public List<Writes> FindbyName(string name , List<Writes> Items)
        {
            List<Writes> tmp = new List<Writes>();
            for (int i = 0; i < Items.Count; i++)
            {
                if (Items[i]._name == name)
                {
                    tmp.Add(Items[i]);
                }
            }
            return tmp;
        }
        public List<Writes> FindbyGeners(string geners, List<Writes> Items)
        {
            List<Writes> tmp = new List<Writes>();
            for (int i = 0; i < Items.Count; i++)
            {
                if (Items[i]._geners == geners)
                {
                    tmp.Add(Items[i]);
                }
            }
            return tmp;
        }
        public List<Writes> FindbyPrice(float price, List<Writes> Items)
        {
            List<Writes> tmp = new List<Writes>();
            for (int i = 0; i < Items.Count; i++)
            {
                if (Items[i]._price == price)

                {
                    tmp.Add(Items[i]);
                }
            }
            return tmp;
        }
        public List<Writes> FindbyPublisher(string publisher, List<Writes> Items)
        {
            List<Writes> tmp = new List<Writes>();
            for (int i = 0; i < Items.Count; i++)
            {
                if (Items[i]._publisher == publisher)

                {
                    tmp.Add(Items[i]);
                }

            }
            return tmp;
        }
        public List<Writes> FindBYAuther(string auther, List<Writes> Items)
        {
            List<Writes> temp = new List<Writes>();
            for (int i = 0; i < Items.Count; i++)
            {
                Book tmp = (Book)Items[i];
                if ((tmp._author == auther))
                {
                    temp.Add(Items[i]);
                }
            }
            return temp;
        }
        public List<Writes> FindBYDate(int year,List<Writes> Items)
        {
            List<Writes> tmp = new List<Writes>();
            for (int i = 0; i < Items.Count; i++)
            {
                if (Items[i]._publish_date.Year == year)

                {
                    tmp.Add(Items[i]);
                }

            }
            return tmp;
        }
    }
}
