﻿using DAL.Repository;
using Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace Logic.Managers
{
    class RemoveManager
    {
        private IRepository repository;
        public RemoveManager(IRepository repository)
        {
            this.repository = repository;
        }

        public List<Writes> Remove(Writes a, List<Writes> Items)
        {
            if (!Items.Contains(a)) throw new Exception("this Writes already  out of the item collection");
            repository.RemoveWrites(a);
            Items = repository.GetWrites();
            return Items;
        }
    }
}
