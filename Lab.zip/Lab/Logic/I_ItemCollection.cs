﻿using Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace Logic
{
    public interface I_ItemCollection
    {
        List<Writes> getItemsList();
        void AddBook(string name, string author, string publisher, DateTimeOffset Date, float price, string geners);
        void AddMagazine(string name, string publisher, DateTimeOffset Date, float price, string geners);
        void RemoveItem(Writes a);

        List<Writes> FindbyName(string name);
        List<Writes> FindbyGeners(string geners);
        List<Writes> FindbyPrice(float price);
        List<Writes> FindbyPublisher(string pub);
        List<Writes> FindBYAuther(string auther);
        List<Writes> FindBYDate(int year);

        void SetDiscount(Writes writes , int Discount);
        void RemoveDiscount(Writes writes);

        void RentItem(Writes writes, string name);
        void ReturnItem(Writes writes);
        void EditItem(Writes writes, string name, string author, string publisher, DateTimeOffset Date, float price, string geners);
        void EditItem(Writes writes, string name, string publisher, DateTimeOffset Date, float price, string geners);
    }
}
