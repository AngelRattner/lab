﻿using DAL.Repository;
using Entity;
using Logic.Managers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Logic
{
    class ItemCollections : I_ItemCollection
    {
        private IRepository repository;
        #region get all Mangers
        AddManager addmanager;
        RemoveManager removeManager;
        DiscountManager discountManager;
        ReturnItemManager ReturnItemManager;
        RentItemManager rentItemManager;
        FindWriteManager findWriteManger = new FindWriteManager();
        #endregion

        List<Writes> Items { get; set; }

        public ItemCollections(IRepository repository)
        {
            this.repository = repository;
            #region set all Mangers
            addmanager = new AddManager(repository);
            removeManager = new RemoveManager(repository);
            discountManager = new DiscountManager(repository);
            ReturnItemManager = new ReturnItemManager(repository);
            rentItemManager = new RentItemManager(repository);
            #endregion
            Items = repository.GetWrites();  //get item from DB
        }

        public void RemoveItem(Writes a)
        {
            Items = removeManager.Remove(a, Items);
        }

        #region find writes functions
        public List<Writes> FindbyName(string name)
        {
            return findWriteManger.FindbyName(name, Items);
        }
        public List<Writes> FindbyGeners(string geners)
        {
            return findWriteManger.FindbyGeners(geners, Items);
        }
        public List<Writes> FindbyPrice(float price)
        {
            return findWriteManger.FindbyPrice(price, Items);
        }
        public List<Writes> FindbyPublisher(string publisher)
        {
            return findWriteManger.FindbyPublisher(publisher, Items);
        }
        public List<Writes> FindBYAuther(string auther)
        {
            return findWriteManger.FindBYAuther(auther, Items);
        }
        public List<Writes> FindBYDate(int year)
        {
            return findWriteManger.FindBYDate(year, Items);
        }
        #endregion

        #region Add
        public void AddBook(string name, string author, string publisher, DateTimeOffset Date, float price, string geners)
        {
            Book book = new Book(name, author, publisher, Date, price, geners);
            AddItem(book);
        }
        public void AddMagazine(string name, string publisher, DateTimeOffset Date, float price, string geners)
        {
            Magazine magazine = new Magazine(name, publisher, Date, price, geners);
            AddItem(magazine);
        }
        void AddItem(Writes a)
        {
            Items = addmanager.Add(a, Items);
        }
        #endregion

        #region Discount

        public void SetDiscount(Writes writes, int discount)
        {
            discountManager.SetDiscount(writes, discount);
        }

        public void RemoveDiscount(Writes writes)
        {
            discountManager.RemoveDiscount(writes);
        }
        #endregion

        public List<Writes> getItemsList()
        {
            return Items;
        }




        public void RentItem(Writes writes, string name)
        {
            rentItemManager.Rent(writes, name);
        }
        public void ReturnItem(Writes writes)
        {
            ReturnItemManager.Return(writes);
        }


        #region Edit
        public void EditItem(Writes writes, string name, string author, string publisher, DateTimeOffset Date, float price, string geners)
        {
            Book book = (Book)writes;
            book._name = name;
            book._publisher = publisher;
            book._publish_date = Date;
            book._geners = geners;
            book._price = price;
            book._author = author;
            EditItem(book);
        }
        public void EditItem(Writes writes, string name, string publisher, DateTimeOffset Date, float price, string geners)
        {
            Magazine magazine= (Magazine)writes;
            magazine._name = name;
            magazine._publisher = publisher;
            magazine._publish_date = Date;
            magazine._geners = geners;
            magazine._price = price;
            EditItem(magazine);
        }
        void EditItem(Writes a)
        {
            Items = addmanager.Add(a, Items);
        }
        #endregion
    }
}
