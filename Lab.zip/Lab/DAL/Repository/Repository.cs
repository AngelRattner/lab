﻿using DAL.Context;
using Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL.Repository
{
    public class Repository : IRepository
    {
        private WritesContext WritesContext;
        public Repository(WritesContext WritesContext)
        {
            this.WritesContext = WritesContext;
        }
        public void EnsureDataBase()
        {
            WritesContext.Database.EnsureCreated();
        }
        public List<Book> GetBooks()
        {
            return WritesContext.Books.ToList();
        }
        public List<Writes> GetWrites()
        {
            return WritesContext.Writes.ToList();
        }


        public void RemoveWrites(Writes Writes)
        {
            WritesContext.Remove(Writes);
            WritesContext.SaveChanges();
        }
        public void AddWrites(Writes Writes)
        {
            WritesContext.Add(Writes);
            WritesContext.SaveChanges();
        }

        public void SetDiscount(Writes writes)
        {
            WritesContext.Update(writes);
            WritesContext.SaveChanges();
        }

        public void RemoveDiscount(Writes writes)
        {
            WritesContext.Update(writes);
            WritesContext.SaveChanges();
        }

        public void EditWrite(Writes writes)
        {
            WritesContext.Update(writes);
            WritesContext.SaveChanges();
        }
    }
}
