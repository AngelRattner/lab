﻿using Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace DAL.Repository
{
    public interface IRepository
    {
        void EnsureDataBase();

        void AddWrites(Writes Writes);
        void RemoveWrites(Writes Writes);
        void EditWrite(Writes writes);
        void SetDiscount(Writes writes);
        void RemoveDiscount(Writes writes);
        //IEnumerable<Writes> FindbyName(string name);
        //IEnumerable<Writes> FindbyGeners(string geners);
        //IEnumerable<Writes> FindbyPrice(float price);
        //IEnumerable<Writes> FindbyPublisher(string publisher);
        //IEnumerable<Writes> FindBYAuther(string auther);

        List<Writes> GetWrites();
        List<Book> GetBooks();
    }
}
