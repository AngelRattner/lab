﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using Entity;

namespace DAL.Context
{
    public class WritesContext : DbContext
    {
        //private static string strConnString = "Server=(localdb)\\AspNetCoreCourse;Database=myDataBase;Trusted_Connection=True";

        public WritesContext(DbContextOptions<WritesContext> options) : base(options)
        {
        }
        public DbSet<Book> Books { get; set; }
        public DbSet<Magazine> Magazines { get; set; }
        public DbSet<Writes> Writes { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Writes>().HasKey(x => x.ID);
            //modelBuilder.Entity<User>().HasKey(x => x.Id);
        }
    }
}
